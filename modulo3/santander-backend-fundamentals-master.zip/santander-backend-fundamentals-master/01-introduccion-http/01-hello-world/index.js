const message = "Hello World";

// Mostrar en la terminal el mensaje "Hello World"
console.log(message);
