import chalk from "chalk";

console.log(chalk.yellow("Hello"), chalk.green("World"), chalk.cyan("!"));
